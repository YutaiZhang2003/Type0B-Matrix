# Higher-genus superconformal blocks

Build: `make -C C++ section6`. Start with [C++/SECTION6.md](C++/SECTION6.md).

The numerical cores are C++17. Python launches and compares them.
The tetrahedron tests use total levels 5 and 10; genus-two tests
use independent-edge levels 5 and 10. Full coefficients are generated
by the test commands. Packaged reports identify completed validations.

The native nonchiral partition comparison uses identity-normalized
NSRR coefficients and the literal paper blocks, including their
Koszul sign; see C++/PARTITION.md for the current result. Its supplied
momentum/geometry bundles remain separate inputs.

Historical result paths in reports identify provenance in the full
working repository. This source bundle excludes large coefficient
archives and unrelated historical tests. Use the Section 6 commands
rather than the older Makefile check targets.
