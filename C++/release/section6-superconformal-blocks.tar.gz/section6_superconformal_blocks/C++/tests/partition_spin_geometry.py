#!/usr/bin/env python3
"""Directed check: paper F pairing versus independently bosonized geometry.

The NS vacuum amplitudes are built from finite Majorana Wick state sums.
Their paper F values include K. The C++ pairing is read from the native
sewing test, and the independent answer is |P theta[0,beta](Omega)|.
No Liouville output or previously reflected block enters this check.
"""
import argparse
import cmath
import itertools
import json
import math
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
for directory in ('Code','Code/genus_2','Code/genus_2_cross_channel'):
    sys.path.insert(0,str(ROOT/directory))
from free_majorana_pair_of_pants import majorana_three_point, ns_fermion_states_at_twice_level
from fixed_spin_free_plumbing import charged_frame, charge_lattice_sum
from spin_structure import SpinCharacteristic


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();start=time.monotonic()
    config=json.loads(args.config.read_text())
    for source,target,charge in zip(config['source_marked_spins'],config['target_marked_spins'],config['target_charge_spins']):
        spin=SpinCharacteristic.from_pairs(source).transport(config['source_to_target'])
        assert spin.pairs==tuple(map(tuple,target))
        assert spin.charge_frame(config['target_period_branch']).pairs==tuple(map(tuple,charge))
    output=subprocess.check_output([str(ROOT/'C++/bin/partition_sewing')],text=True)
    native=[json.loads(line) for line in output.splitlines()]
    pairing=native[-1]['NS_pairings'][0]
    q=tuple(complex(z) for z in config['point']['q_target'])
    geometry=charged_frame(q[::-1],max_mode=20)
    cutoff=8
    states=[ns_fermion_states_at_twice_level(n) for n in range(2*cutoff+1)]
    coefficients={}
    for n1 in range(2*cutoff+1):
        for n2 in range(2*cutoff+1-n1):
            for n3 in range(2*cutoff+1-n1-n2):
                value=sum(majorana_three_point(*triple)**2 for triple in itertools.product(states[n1],states[n2],states[n3]))
                if value: coefficients[n1,n2,n3]=value
    signs=((1,1,1),(1,-1,1),(1,1,-1),(1,-1,-1))
    F=[0j]*4
    for n,value in coefficients.items():
        epsilon=tuple(x%2 for x in n)
        K=sum(epsilon[i]*epsilon[j] for i in range(3) for j in range(i+1,3))%2
        monomial=cmath.exp(sum(x*cmath.log(z)/2 for x,z in zip(n,q)))
        for i,lift in enumerate(signs):
            F[i]+=(-1)**K*value*monomial*math.prod(s**e for s,e in zip(lift,epsilon))
    rows=[]
    for spin,beta in enumerate(((0,0),(0,1),(1,0),(1,1))):
        actual=sum(pairing[spin][4*i+j]*F[i]*F[j].conjugate()/16 for i in range(4) for j in range(4))
        expected=abs(geometry.boson_chiral*charge_lattice_sum(geometry.omega_charge,((0,0),beta),cutoff=5))
        relative=abs(actual/expected-1)
        if relative>2e-8:
            raise AssertionError((beta,actual,expected,relative))
        rows.append(dict(charge_beta=beta,relative_error=relative,paper_pairing_Z=actual.real,
                         bosonization_Z=expected,incorrect_diagonal_relative_error=abs(abs(F[spin])**2/expected-1)))
    report=dict(level=cutoff,seconds=time.monotonic()-start,native_pairing_tests=native[:2],
                spin_transport_cases=2,Majorana_Wick_monomials=len(coefficients),rows=rows,
                maximum_relative_error=max(row['relative_error'] for row in rows))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()
