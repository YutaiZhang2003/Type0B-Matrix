#include "scblocks/partition_sewing.hpp"
#include "scblocks/json_input.hpp"
#include "ramond/storage.hpp"
#include <iostream>
using namespace ramond;
namespace nc=scblocks::nonchiral;

template<class S> double check(double tolerance) {
    S I(Machine(0,1)),rt=root(S(2)),u=(S(1)-I)/rt,ub=(S(1)+I)/rt;
    std::array<std::array<S,2>,4> right{{{S(1)/rt,0},{0,ub/rt},{0,u/rt},{-I/rt,0}}};
    std::array<std::array<S,2>,4> left{{{S(1)/rt,0},{0,-u/rt},{0,-ub/rt},{-I/rt,0}}};
    double error=0;
    auto equal=[&](S a,S b) {error=std::max(error,magnitude(a-b)/std::max(1.,magnitude(b)));};
    for(int e=0;e<2;e++)for(int f=0;f<2;f++) {
        S pair=0;for(int j=0;j<4;j++)pair+=left[j][e]*S(j? -1:1)*right[j][f];
        equal(pair,S(e==f));
    }
    // Independent ket/ket three-point contraction in the four-dimensional
    // graded Clifford space. The inverse Gram uses the left embedding above.
    auto family=[&](int a,int b,int eta) {
        std::array<S,4> rh=a?std::array<S,4>{0,1,I*S(eta),0}:std::array<S,4>{1,0,0,I*S(eta)};
        std::array<S,4> ra=b?std::array<S,4>{0,1,-I*S(eta),0}:std::array<S,4>{1,0,0,-I*S(eta)};
        std::array<S,4> k{};
        for(int e=0;e<2;e++)for(int f=0;f<2;f++)
        for(int al=0;al<2;al++)for(int be=0;be<2;be++)
        for(int ga=0;ga<2;ga++)for(int de=0;de<2;de++)
            k[2*e+f]+=right[2*al+be][e]*right[2*ga+de][f]*S(sign(b*(a+al+ga)+be*ga))*rh[2*al+ga]*ra[2*be+de];
        return k;
    };
    int family_cases=0;
    for(int a:{0,1})for(int b:{0,1})for(int s:{1,-1})
    for(int eta:{1,-1})for(int etap:{1,-1}) {
        auto kl=family(a,b,eta),kr=family(a,b,etap);S direct=0;
        for(int e=0;e<2;e++)for(int f=0;f<2;f++)
            direct+=S((a+b)%2?s:1)*kl[2*e+f]*conjugate(kr[2*e+f]);
        // Literal paper F reconstructed from its two allowed parity components.
        auto literal=[&](int ns_parity) {
            nc::F_R<S> F{};
            for(int form=0;form<2;form++) {
                int epsilon=ns_parity+4*(ns_parity^form);
                std::array<S,8> row{};
                row[epsilon]=form ? -I*S(sign(ns_parity)) : S(1);
                row[epsilon^6]=row[epsilon]*S(eta*etap*sign(ns_parity+form));
                for(int lift=0;lift<4;lift++)F[nc::channel(form,eta,etap)][lift]=nc::evaluate_parity(row,nc::eta_e[lift]);
            }
            return F;
        };
        auto F=literal(a),Ftilde=nc::conjugated(literal(b));
        nc::C_f_eta<S> C_left{},C_right{};
        for(int f=0;f<2;f++) {C_left[f][eta==-1]=1;C_right[f][etap==-1]=1;}
        equal(nc::Z_R(F,Ftilde,C_left,C_right,s==1?0:1,S(1)),direct);family_cases++;
        S z=I+S(2),w=I*S(3)-S(1);
        for(auto &row:F)for(auto& x:row)x*=z;
        for(auto &row:Ftilde)for(auto& x:row)x*=w;
        equal(nc::Z_R(F,Ftilde,C_left,C_right,s==1?0:1,S(1)),z*w*direct);
    }
    // The full-state graded sewing reduces to the two chiral K signs plus a.
    auto K=[](int e) {return ((e&1)*((e>>1)&1)+(e&1)*((e>>2)&1)+((e>>1)&1)*((e>>2)&1))%2;};
    int graded_cases=0;
    for(int e=0;e<8;e++)for(int t=0;t<8;t++)if(__builtin_popcount(unsigned(e))%2==__builtin_popcount(unsigned(t))%2) {
        int a=__builtin_popcount(unsigned(e))%2;
        equal(S(sign(K(e^t)+__builtin_popcount(unsigned(e&t)))),S(sign(K(e)+K(t)+a)));
        graded_cases++;
    }
    nc::F_NS<S> F{},Ft{}; std::array<S,2> C_a{S(2),I*S(3)};
    std::array<std::array<S,8>,2> t{},tt{};
    for(int a=0;a<2;a++)for(int e=0;e<8;e++)if(__builtin_popcount(unsigned(e))%2==a) {
        t[a][e]=S(1+e)+I*S(2-e);tt[a][e]=S(3-e)-I*S(1+e);
        for(int lift=0;lift<4;lift++) {
            S character=S(sign(K(e))*nc::character(nc::eta_e[lift],e));
            F[a][lift]+=character*t[a][e];Ft[a][lift]+=character*tt[a][e];
        }
    }
    // Independent state-parity contraction: no block basis conversion here.
    for(int spin=0;spin<4;spin++) {
        S state_sum=0;
        for(int a=0;a<2;a++)for(int e=0;e<8;e++)for(int d=0;d<8;d++)
            state_sum+=S(sign(a)*nc::character(nc::eta_e[spin],e^d))*C_a[a]*C_a[a]*t[a][e]*tt[a][d];
        equal(nc::Z_NS(F,Ft,C_a,C_a,spin,S(1)),state_sum);
    }
    nc::F_R<S> identity{};
    identity[nc::channel(0,1,1)]={2,0,0,2};
    identity[nc::channel(1,1,1)]={0,-I*S(2),I*S(2),0};
    nc::C_f_eta<S> C_f_eta{{{1,0},{1,0}}};
    for(int spin:{0,1})equal(nc::Z_R(identity,nc::conjugated(identity),C_f_eta,C_f_eta,spin,S(1)),S(2));

    require(error<tolerance,"partition sewing validation failed");
    std::cout<<"{\"clifford_family_cases\":"<<family_cases<<",\"NS_graded_sign_cases\":"<<graded_cases<<",\"maximum_scaled_error\":"<<error<<"}"<<std::endl;
    return error;
}
int main() {
    try {
        MP::precision(40);check<Machine>(1e-13);check<MP>(1e-38);
        auto x=scblocks::Json::parse("{\"x\":1.234567890123456789012345678901234567890e-40,\"s\":\"a\\nb\"}");
        require(x.at("x").scalar()=="1.234567890123456789012345678901234567890e-40","decimal input lost precision");
        for(auto bad:{"{\"x\":1,\"x\":2}","[1,]","01","1e","{\"x\":NaN}"}) {
            bool rejected=false;try{scblocks::Json::parse(bad);}catch(const std::exception&){rejected=true;}
            require(rejected,"invalid JSON accepted");
        }
        std::cout<<"{\"NS_pairings_denominator\":16,\"NS_pairings\":[";
        for(int a=0;a<2;a++) {
            if(a)std::cout<<',';std::cout<<'[';
            for(int spin=0;spin<4;spin++) {
                if(spin)std::cout<<',';std::cout<<'[';auto m=nc::NS_pairing(a,spin);
                for(int j=0;j<16;j++){if(j)std::cout<<',';std::cout<<m[j];}std::cout<<']';
            }
            std::cout<<']';
        }
        std::cout<<"]}\n";
        return 0;
    }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}
}
