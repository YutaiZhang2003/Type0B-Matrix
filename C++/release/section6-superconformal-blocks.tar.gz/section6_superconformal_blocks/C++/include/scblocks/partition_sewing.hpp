#pragma once
#include "ramond/number.hpp"
#include <array>

namespace scblocks::nonchiral {
using ramond::Machine;
using ramond::require;
inline constexpr const char* coefficient_convention="unit_identity_upsilon_coefficients_2026-09-24";
inline constexpr const char* sewing_convention="paper_F_geometric_pairing_2026-09-24";
// Paper edge order: (1,2,3)=(infinity,1,0). Fix eta_1=+1.
inline constexpr std::array<std::array<int,3>,4> eta_e{{{1,1,1},{1,-1,1},{1,1,-1},{1,-1,-1}}};
template<class S> using F_NS = std::array<std::array<S,4>,2>; // [a][eta_e]
template<class S> using F_R = std::array<std::array<S,4>,8>; // [f,eta,eta'][eta_e]
template<class S> using C_f_eta = std::array<std::array<S,2>,2>; // [f][eta=+,-]
inline int channel(int f,int eta,int etap) {
    require((f==0 || f==1) && (eta==1 || eta==-1) && (etap==1 || etap==-1),"invalid channel");
    return 4*f+2*(eta==-1)+(etap==-1);
}
inline int character(const std::array<int,3>& signs,int epsilon) {
    int value=1;
    for(int e=0;e<3;e++) {
        require(signs[e]==1 || signs[e]==-1,"eta_e must be +/-1");
        if(epsilon&(1<<e))value*=signs[e];
    }
    return value;
}
template<class S> S evaluate_parity(const std::array<S,8>& F,const std::array<int,3>& signs) {
    S value=0;
    for(int epsilon=0;epsilon<8;epsilon++)value+=S(character(signs,epsilon))*F[epsilon];
    return value;
}
// Fixed-spin physical sewing expressed in the paper's F basis. The
// geometry's charge-spin character is not the lift argument of a single F.
// F_i=sum_epsilon chi_i(epsilon) (-1)^K(epsilon) t_epsilon.
// The state pairing weighs t_epsilon ttilde_delta by chi_spin(epsilon+delta).
// Fourier inversion gives the integer matrix below, with denominator 16.
// This changes the sewing coefficients, never F or its stored coefficients.
inline int K(int e) {
    return ((e&1)*((e>>1)&1)+(e&1)*((e>>2)&1)+((e>>1)&1)*((e>>2)&1))%2;
}
inline std::array<int,16> NS_pairing(int a,int spin) {
    require((a==0 || a==1) && spin>=0 && spin<4,"invalid NS sewing sector");
    std::array<int,16> result{};
    for(int i=0;i<4;i++)for(int j=0;j<4;j++)
        for(int e=0;e<8;e++)if(__builtin_popcount(unsigned(e))%2==a)
            for(int t=0;t<8;t++)if(__builtin_popcount(unsigned(t))%2==a)
                result[4*i+j]+=(K(e)+K(t))%2?-character(eta_e[spin],e^t)*character(eta_e[i],e)*character(eta_e[j],t)
                                                           :character(eta_e[spin],e^t)*character(eta_e[i],e)*character(eta_e[j],t);
    return result;
}
// C_a includes the i in C_1. Antiholomorphic inputs are independent.
template<class S> S Z_NS(const F_NS<S>& F,const F_NS<S>& Ftilde,
                         const std::array<S,2>& C_a_left,const std::array<S,2>& C_a_right,
                         int spin,S propagation) {
    S value=0;
    for(int a=0;a<2;a++) {
        const auto pairing=NS_pairing(a,spin);
        S weight=S(a?-1:1)*C_a_left[a]*C_a_right[a]/S(16);
        for(int i=0;i<4;i++)for(int j=0;j<4;j++)value+=weight*S(pairing[4*i+j])*F[a][i]*Ftilde[a][j];
    }
    return propagation*value;
}
// Fixed geometric R spins [11|00] and [11|11] in the source chart.
// The physical two-family ket/dual contraction gives eta'=eta and f=0,
// with coefficient 1/2 for each of the four displayed lift-pair terms.
// The second characteristic reverses the NS parity character. For f=0,
// F(-1,1,1)=F(1,-1,-1) and F(-1,-1,1)=F(1,1,-1).
// No new/projected block is formed. C_{1,eta}=C_{0,eta} in this spectrum.
template<class S> S Z_R(const F_R<S>& F,const F_R<S>& Ftilde,
                        const C_f_eta<S>& C_left,const C_f_eta<S>& C_right,
                        int spin,S propagation) {
    require(spin==0 || spin==1,"source requires [11|00] or [11|11]");
    S value=0;
    for(int eta:{1,-1})for(int i=2*spin;i<2*spin+2;i++)for(int j=2*spin;j<2*spin+2;j++)
        value+=C_left[0][eta==-1]*C_right[0][eta==-1]*F[channel(0,eta,eta)][i]*Ftilde[channel(0,eta,eta)][j]/S(2);
    return propagation*value;
}
template<class S,size_t N> std::array<std::array<S,4>,N> conjugated(const std::array<std::array<S,4>,N>& F) {
    auto Ftilde=F;
    for(auto& row:Ftilde)for(auto& value:row)value=ramond::conjugate(value);
    return Ftilde;
}
} // namespace scblocks::nonchiral
