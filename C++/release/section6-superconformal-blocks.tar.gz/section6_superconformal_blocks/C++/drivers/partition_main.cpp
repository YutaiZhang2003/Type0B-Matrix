#include "scblocks/ns_recursion.hpp"
#include "scblocks/json_input.hpp"
#include "scblocks/partition_sewing.hpp"
#include "ramond/pipeline.hpp"
#include <filesystem>
#include <sys/wait.h>
#include <cerrno>
#include <unistd.h>

namespace fs=std::filesystem;
using namespace ramond;
using scblocks::Json;
using scblocks::json_quote;
namespace nc=scblocks::nonchiral;
using Scalar=MP;

Scalar log_value(const Scalar &x) { Scalar y; mpc_log(y.data(),x.data(),MPC_RNDNN); return y; }
Scalar exp_value(const Scalar &x) { Scalar y; mpc_exp(y.data(),x.data(),MPC_RNDNN); return y; }
Scalar number(const Json &j) {
    if(j.kind==Json::Array) {
        require(j.array.size()==2,"complex array must have two components");
        return parse<Scalar>(j.at(0).scalar()+","+j.at(1).scalar());
    }
    if(j.kind==Json::Object) return parse<Scalar>(j.at("real").scalar()+","+j.at("imag").scalar());
    auto s=j.scalar();
    if(s.find('j')==std::string::npos) return parse<Scalar>(s);
    if(s.front()=='(' && s.back()==')') s=s.substr(1,s.size()-2);
    require(s.back()=='j',"invalid complex plumbing input"); s.pop_back();
    size_t split=std::string::npos;
    for(size_t i=1;i<s.size();i++) if((s[i]=='+' || s[i]=='-') && s[i-1]!='e' && s[i-1]!='E') split=i;
    require(split!=std::string::npos,"complex plumbing needs real and imaginary parts");
    return parse<Scalar>(s.substr(0,split)+","+s.substr(split));
}
template<size_t N> std::array<Scalar,N> numbers(const Json &j) {
    require(j.kind==Json::Array && j.array.size()==N,"incorrect input vector size");
    std::array<Scalar,N> x; for(size_t i=0;i<N;i++) x[i]=number(j.at(i)); return x;
}
template<size_t N> void vector_json(std::ostream &o,const std::array<Scalar,N>& v) {
    o<<'['; for(size_t i=0;i<N;i++) {if(i)o<<',';o<<json_number(v[i]);}o<<']';
}
void validate_config(const Json &config) {
    require(config.at("schema").scalar()=="paper-partition-input-v1", "convert historical geometry inputs with prepare_partition_inputs.py");
    auto check_spins=[&](const char* key,const std::array<std::array<int,4>,2>& expected) {
        const auto& spins=config.at(key);
        require(spins.kind==Json::Array && spins.array.size()==2,"two geometric spin characteristics required");
        for(int row=0;row<2;row++)for(int bit=0;bit<4;bit++)
            require(spins.at(row).at(bit/2).at(bit%2).integer()==expected[row][bit],"unsupported geometric spin dictionary");
    };
    check_spins("source_marked_spins",{{{1,1,0,0},{1,1,1,1}}});
    check_spins("target_marked_spins",{{{0,0,0,0},{0,0,1,0}}});
    check_spins("target_charge_spins",{{{0,0,1,0},{0,0,0,0}}});
    Scalar b=number(config.at("b"));
    require(machine(b).real()>0 && machine(b).imag()==0,"positive real b required");
    const auto &point=config.at("point");
    for(auto name:{"q_source","q_target"})for(auto q:numbers<3>(point.at(name)))
        require(magnitude(q)>0 && magnitude(q)<1,"plumbing values must have 0 < |q| < 1");
    for(auto name:{"source_free","target_free"}) {
        Scalar f=number(point.at(name));require(machine(f).real()>0 && machine(f).imag()==0,"positive free-frame factor required");
    }

}
void atomic(const fs::path &path,const std::string &s) {
    if(!path.parent_path().empty())fs::create_directories(path.parent_path());
    std::ofstream out(path.string()+".partial"); require(bool(out),"cannot open output");
    out<<s;out.close();require(bool(out),"failed output write");fs::rename(path.string()+".partial",path);
}
struct Options {
    std::string channel,config,node_directory,output,source,target;
    int level=5,minimum=-1,dps=40,workers=1,index=-1;
};
std::vector<fs::path> node_paths(const fs::path &p) {
    std::vector<fs::path> out;
    for(auto &entry:fs::directory_iterator(p))
        if(entry.is_regular_file() && entry.path().extension()==".json" && entry.path().filename().string().rfind("node-",0)==0) out.push_back(entry.path());
    std::sort(out.begin(),out.end());require(!out.empty(),"no momentum nodes");return out;
}
Scalar primary(Scalar b,const std::array<Scalar,3>& p,const std::array<Scalar,3>& q,bool rr) {
    Scalar Q=b+Scalar(1)/b,ans=0;
    for(int e=0;e<3;e++) {
        Scalar h=Q*Q/Scalar(8)+p[e]*p[e]/Scalar(2)+(rr && e>0?rational<Scalar>(1,16):Scalar(0));
        ans+=h*log_value(q[e]);
    }
    return exp_value(ans);
}
std::map<int,nc::F_R<Scalar>> source_blocks(const Options& opts,Scalar b,const std::array<Scalar,3>& p,
                                              const std::array<Scalar,3>& q,double &ward,double &sector) {
    std::map<int,nc::F_R<Scalar>> out;
    for(int l=opts.minimum;l<=opts.level;l++)out[l]={};
    std::array<Scalar,3> logs{log_value(q[0]),log_value(q[1]),log_value(q[2])};
    // Both f are computed directly. No projected-block identity is used.
    // Both geometric source spins have the same R-family pairing, eta'=eta.
    for(int eta:{1,-1})for(int f=0;f<2;f++) {
        Settings s;s.inserted=false;s.box=false;s.record_sector=false;s.p=0;s.f=f;s.eta=eta;
        s.level=opts.level;s.dps=opts.dps;s.b=decimal(mpc_realref(b.data()));
        for(int e=0;e<3;e++)s.momenta[e]="0,"+decimal(mpc_realref(p[e].data()));
        auto result=pipeline<Scalar>(s);
        ward=std::max(ward,result.ward_residual);sector=std::max(sector,result.sector_residual);
        for(const auto &[k,row]:result.physical) {
            require(k[1]==k[2],"source must use original physical edge degrees");
            Scalar monomial=exp_value(Scalar(k[0])*logs[0]/Scalar(2)+Scalar(k[1])*logs[1]+Scalar(k[3])*logs[2]/Scalar(2));
            for(int lift=0;lift<4;lift++) {
                Scalar value=nc::evaluate_parity(row,nc::eta_e[lift])*monomial;
                for(auto &[l,F]:out)if(degree(k)<=2*l)F[nc::channel(f,eta,eta)][lift]+=value;
            }
        }
    }
    return out;
}
using LiftBlocks=nc::F_NS<Scalar>;
std::map<int,LiftBlocks> target_blocks(const Options& opts,Scalar b,const std::array<Scalar,3>& p,
                                     const std::array<Scalar,3>& q,const scblocks::QPoly& vacuum,
                                     size_t &transitions,size_t &seed_terms) {
    scblocks::Setup setup("theta_ns");
    Scalar Q=b+Scalar(1)/b,c=rational<Scalar>(3,2)+Scalar(3)*Q*Q;
    std::vector<Scalar> h;
    std::array<Scalar,3> logs{log_value(q[0]),log_value(q[1]),log_value(q[2])};
    for(int e=0;e<3;e++)h.push_back(Q*Q/Scalar(8)+p[e]*p[e]/Scalar(2));
    scblocks::NSRecursion recursion(setup.graph,c,h,vacuum);
    auto coefficients=recursion.coefficients(scblocks::indices(setup,opts.level));
    transitions=recursion.transitions;seed_terms=recursion.seed_terms;
    std::map<int,LiftBlocks> out;
    for(int l=opts.minimum;l<=opts.level;l++)out[l]={};
    for(const auto &[k,co]:coefficients) {
        int form=scblocks::total(k)%2;
        int epsilon=(k[0]%2)+2*(k[1]%2)+4*(k[2]%2);
        Scalar x=co*exp_value((Scalar(k[0])*logs[0]+Scalar(k[1])*logs[1]+Scalar(k[2])*logs[2])/Scalar(2));
        for(auto &[l,f]:out)if(scblocks::total(k)<=2*l)
            for(int lift=0;lift<4;lift++)f[form][lift]+=Scalar(nc::character(nc::eta_e[lift],epsilon))*x;
    }
    return out;
}
void calculate_node(const Options& opts,const Json& config,const fs::path& input,const scblocks::QPoly& vacuum) {
    double started=seconds();
    Json node=Json::read(input.string());
    // Only these physical input fields participate in the new calculation.
    auto p=numbers<3>(node.at("momenta"));
    require(node.at("schema").scalar()=="paper-partition-node-input-v1","input convention missing");
    std::array<Scalar,2> C_a{}; nc::C_f_eta<Scalar> C_f_eta{};
    if(opts.channel=="target") C_a=numbers<2>(node.at("C_a"));
    else for(int f=0;f<2;f++) C_f_eta[f]=numbers<2>(node.at("C_f_eta").at(f));
    require(node.at("N").integer()>0 && node.at("index").integer()>=0,"invalid quadrature node labels");
    if(node.has("channel"))require(node.at("channel").scalar()==opts.channel,"input node is from the other channel");
    Scalar measure=number(node.at("measure")),b=number(config.at("b"));
    require(machine(measure).real()>0 && machine(measure).imag()==0,"invalid momentum measure");
    for(auto &x:p)require(machine(x).real()>0 && machine(x).imag()==0,"positive continuum momenta required");
    auto q=numbers<3>(config.at("point").at(opts.channel=="source"?"q_source":"q_target"));
    Scalar prim=primary(b,p,q,opts.channel=="source");
    Scalar propagation=measure*prim*conjugate(prim);
    std::ostringstream out;out<<std::setprecision(17);
    out<<"{\"schema\":\"paper-native-partition-node-v3\",\"conventions\":\"product_bpz_residue_2026-09-22\","
       <<"\"coefficient_convention\":"<<json_quote(nc::coefficient_convention)<<','
       <<"\"sewing_convention\":"<<json_quote(nc::sewing_convention)<<','
       <<"\"implementation\":\"C++17\",\"normalization_factor\":1,\"chiral_blocks_fresh\":true,"
       <<"\"source_input\":"<<json_quote(input.string())<<",\"channel\":"<<json_quote(opts.channel)
       <<",\"index\":"<<node.at("index").integer()<<",\"N\":"<<node.at("N").integer()
       <<",\"dps\":"<<opts.dps<<",\"level\":"<<opts.level<<",\"minimum_level\":"<<opts.minimum
       <<",\"truncation\":\"total descendant level in both channels\",\"momenta\":";
    vector_json(out,p);out<<",\"edge_order\":[1,2,3],\"eta_e\":[[1,1,1],[1,-1,1],[1,1,-1],[1,-1,-1]]";
    if(opts.channel=="target") {out<<",\"C_a\":";vector_json(out,C_a);}
    else {out<<",\"C_f_eta\":[";vector_json(out,C_f_eta[0]);out<<',';vector_json(out,C_f_eta[1]);out<<']';}
    out<<",\"measure\":"<<json_number(measure)<<",\"primary\":"<<json_number(prim)<<",\"rows\":[";
    double ward=0,sector=0;size_t transitions=0,seed_terms=0;
    if(opts.channel=="source") {
        auto all=source_blocks(opts,b,p,q,ward,sector);
        int count=0;
        for(auto &[l,F]:all) {
            auto Ftilde=nc::conjugated(F);
            std::array<Scalar,4> Z{};
            Z[0]=nc::Z_R(F,Ftilde,C_f_eta,C_f_eta,0,propagation);
            Z[1]=nc::Z_R(F,Ftilde,C_f_eta,C_f_eta,1,propagation);
            Z[2]=Z[0]+Z[1];
            if(count++)out<<',';
            out<<"{\"level\":"<<l<<",\"F\":[";
            int entry=0;
            for(int f=0;f<2;f++)for(int eta:{1,-1}) {
                if(entry++)out<<',';
                out<<"{\"f\":"<<f<<",\"eta\":"<<eta<<",\"eta_prime\":"<<eta<<",\"values\":";
                vector_json(out,F[nc::channel(f,eta,eta)]);out<<'}';
            }
            out<<"],\"Z\":";vector_json(out,Z);out<<'}';
        }
    } else {
        auto all=target_blocks(opts,b,p,q,vacuum,transitions,seed_terms);
        int count=0;
        for(auto &[l,F]:all) {
            auto Ftilde=nc::conjugated(F); std::array<Scalar,4> Z{};
            for(int lift=0;lift<4;lift++) Z[lift]=nc::Z_NS(F,Ftilde,C_a,C_a,lift,propagation);
            if(count++)out<<',';out<<"{\"level\":"<<l<<",\"F\":[";
            vector_json(out,F[0]);out<<',';vector_json(out,F[1]);out<<"],\"Z\":";vector_json(out,Z);out<<'}';
        }
    }
    out<<"],\"maximum_ward_residual\":"<<ward<<",\"maximum_sector_residual\":"<<sector
       <<",\"ns_transitions\":"<<transitions<<",\"ns_seed_terms\":"<<seed_terms
       <<",\"seconds\":"<<seconds()-started<<"}\n";
    atomic(fs::path(opts.output)/input.filename(),out.str());
}
void integrate(const Options& opts,const Json& config) {
    auto collect=[&](const std::string& dir,const std::string& expected) {
        auto run=Json::read((fs::path(dir)/"run.json").string());
        require(run.at("complete").kind==Json::Bool && run.at("complete").text=="true","run did not complete");
        require(run.at("config").scalar()==opts.config && run.at("channel").scalar()==expected,"run/configuration mismatch");
        auto files=node_paths(dir);std::map<int,std::array<Scalar,4>> sums;int N=-1;
        std::set<int> seen;
        for(const auto &path:files) {
            auto d=Json::read(path.string());
            require(d.at("channel").scalar()==expected && d.at("normalization_factor").integer()==1,"wrong channel/normalization");
            require(d.at("conventions").scalar()=="product_bpz_residue_2026-09-22","wrong conventions");
            require(d.has("sewing_convention") && d.at("sewing_convention").scalar()==nc::sewing_convention,
                    "obsolete nonchiral sewing: recompute geometric pairing in the paper F basis");
            require(d.has("coefficient_convention") && d.at("coefficient_convention").scalar()==nc::coefficient_convention,
                    "obsolete or mixed structure-constant normalization; recompute with the identity-normalized coefficients");
            require(d.at("dps").integer()==run.at("dps").integer() && d.at("dps").integer()<=opts.dps,"mixed or insufficient reduction precision");
            int lower=run.at("minimum_level").integer(),upper=run.at("level").integer();
            require(d.at("minimum_level").integer()==lower && d.at("level").integer()==upper,"mixed cutoffs");
            require(int(d.at("rows").array.size())==upper-lower+1,"missing level rows");
            if(N<0)N=d.at("N").integer();require(N==d.at("N").integer(),"mixed grids");
            require(seen.insert(d.at("index").integer()).second,"duplicate node");
            for(auto &row:d.at("rows").array) {
                int l=row.at("level").integer();require(l==lower++,"missing or duplicate level row");
                auto values=numbers<4>(row.at("Z"));
                for(int i=0;i<4;i++)sums[l][i]+=values[i];
            }
        }
        require(int(files.size())==N*N*N,"incomplete tensor grid");
        for(int j=0;j<N*N*N;j++)require(seen.count(j),"missing node index");
        return std::make_pair(N,sums);
    };
    auto src=collect(opts.source,"source"),tar=collect(opts.target,"target");
    Scalar b=number(config.at("b")),Q=b+Scalar(1)/b,kappa=Scalar(1)+Scalar(2)*Q*Q;
    Scalar frame=exp_value(kappa*log_value(number(config.at("point").at("source_free"))/number(config.at("point").at("target_free"))));
    std::ostringstream out;out<<std::setprecision(17)<<"{\"schema\":\"paper-native-partition-comparison-v3\","
       <<"\"coefficient_convention\":"<<json_quote(nc::coefficient_convention)<<','
       <<"\"sewing_convention\":"<<json_quote(nc::sewing_convention)<<','
       <<"\"implementation\":\"C++17\",\"normalization_factor\":1,\"source_N\":"<<src.first<<",\"target_N\":"<<tar.first
       <<",\"free_frame_power\":"<<json_number(frame)<<",\"physical_inputs\":\"frozen momenta, measures, SCFT constants, geometry and free-frame factors; no saved chiral blocks used\","
       <<"\"spin_transport_status\":\"The two marked spins are compared separately using the charge-spin pairing in the paper F basis; no coherent mixing between geometric spin structures.\",\"comparisons\":[";
    int count=0;
    for(auto &[sl,sz]:src.second)for(auto &[tl,tz]:tar.second) {
        Scalar source_sum=sz[0]+sz[1],target_sum=tz[2]+tz[0];
        std::array<Scalar,2> ratios{sz[0]/tz[2]/frame,sz[1]/tz[0]/frame};
        require(magnitude(target_sum)>0,"zero target denominator");
        require(magnitude(source_sum-real_number(source_sum))<1e-30*magnitude(source_sum),"nonreal source sum");
        require(magnitude(target_sum-real_number(target_sum))<1e-30*magnitude(target_sum),"nonreal target sum");
        if(count++)out<<',';
        out<<"{\"source_level\":"<<sl<<",\"target_level\":"<<tl<<",\"source_Z\":";vector_json(out,sz);
        out<<",\"target_Z\":";vector_json(out,tz);
        out<<",\"fixed_spin_ratios\":";vector_json(out,ratios);
        out<<",\"source_two_spin_sum\":"<<json_number(source_sum)
           <<",\"target_two_spin_sum\":"<<json_number(target_sum)
           <<",\"two_spin_sum_ratio\":"<<json_number(source_sum/target_sum/frame)<<'}';
    }
    out<<"],\"source_Z_order\":[\"marked [11|00]\",\"marked [11|11]\",\"sum\",\"unused\"],"
       <<"\"target_charge_beta_order\":[[0,0],[0,1],[1,0],[1,1]],"
       <<"\"target_summed_charge_beta\":[[1,0],[0,0]]}\n";
    atomic(opts.output,out.str());
}
int main(int argc,char**argv) {
    try {
        Options opts;
        for(int i=1;i<argc;i++) {
            std::string key=argv[i];
            if(key=="--help") {
                std::cout<<"partition --config frozen-config.json --node-directory DIR --channel source|target\n"
                         <<"  --level N --minimum-level M --dps 40 --workers 4 --output DIR [--index I]\n"
                         <<"partition --config frozen-config.json --reduce-source DIR --reduce-target DIR --output FILE\n"
                         <<"Input node fields: index, N, momenta (paper edge order), measure, C_a or C_f_eta.\n"
                         <<"Both channels are calculated natively at total descendant cutoff. No factor-four option.\n";return 0;
            }
            require(i+1<argc,"missing option value");std::string value=argv[++i];
            if(key=="--config")opts.config=value;
            else if(key=="--node-directory")opts.node_directory=value;
            else if(key=="--channel")opts.channel=value;
            else if(key=="--level")opts.level=std::stoi(value);
            else if(key=="--minimum-level")opts.minimum=std::stoi(value);
            else if(key=="--dps")opts.dps=std::stoi(value);
            else if(key=="--workers")opts.workers=std::stoi(value);
            else if(key=="--index")opts.index=std::stoi(value);
            else if(key=="--output")opts.output=value;
            else if(key=="--reduce-source")opts.source=value;
            else if(key=="--reduce-target")opts.target=value;
            else throw std::runtime_error("unknown option: "+key);
        }
        require(!opts.config.empty() && !opts.output.empty(),"config and output required");
        require(opts.dps>=30 && opts.dps<=10000,"partition driver needs 30 to 10000 decimal digits");
        MP::precision(opts.dps);auto config=Json::read(opts.config);validate_config(config);
        if(!opts.source.empty() || !opts.target.empty()) {
            require(!opts.source.empty() && !opts.target.empty(),"both reduction directories required");
            integrate(opts,config);return 0;
        }
        require(opts.channel=="source" || opts.channel=="target","select source or target");
        require(opts.level>=0 && opts.level<=20 && opts.workers>=1,"invalid run controls");
        if(opts.minimum<0)opts.minimum=opts.level;
        require(opts.minimum>=0 && opts.minimum<=opts.level,"invalid minimum level");
        fs::create_directories(opts.output);auto paths=node_paths(opts.node_directory);
        if(opts.index>=0) {
            std::vector<fs::path> chosen;
            for(auto &p:paths)if(Json::read(p.string()).at("index").integer()==opts.index)chosen.push_back(p);
            require(chosen.size()==1,"selected node missing or duplicated");paths=chosen;
        }
        for(auto &p:paths)require(!fs::exists(fs::path(opts.output)/p.filename()),"output already exists; use a fresh run directory");
        double started=seconds();scblocks::QPoly vacuum;
        if(opts.channel=="target") {
            scblocks::Setup setup("theta_ns");vacuum=scblocks::ns_schottky(setup.graph,setup.domain(opts.level));
        }
        double seed_seconds=seconds()-started;
        std::vector<pid_t> children;
        int workers=std::min(opts.workers,int(paths.size()));
        for(int w=0;w<workers;w++) {
            pid_t pid=fork();require(pid>=0,"fork failed");
            if(!pid) {
                std::ofstream log(fs::path(opts.output)/("worker-"+std::to_string(w)+".log"));std::cerr.rdbuf(log.rdbuf());
                try {
                    for(size_t j=w;j<paths.size();j+=workers) {
                        calculate_node(opts,config,paths[j],vacuum);
                        std::cerr<<"completed "<<paths[j].filename()<<'\n';
                    }
                    log.flush();_exit(0);
                } catch(const std::exception &e) {std::cerr<<"FAILED: "<<e.what()<<'\n';log.flush();_exit(1);}
            }
            children.push_back(pid);
        }
        bool ok=true;
        for(pid_t pid:children) {
            int status=0;pid_t result;
            do {result=waitpid(pid,&status,0);}while(result<0 && errno==EINTR);
            require(result==pid,"waitpid failed");ok=ok && WIFEXITED(status) && WEXITSTATUS(status)==0;
        }
        std::ostringstream report;report<<std::setprecision(17)<<"{\"complete\":"<<(ok?"true":"false")<<",\"channel\":"<<json_quote(opts.channel)
            <<",\"config\":"<<json_quote(opts.config)<<",\"node_directory\":"<<json_quote(opts.node_directory)<<",\"nodes\":"<<paths.size()
            <<",\"workers\":"<<workers<<",\"level\":"<<opts.level<<",\"minimum_level\":"<<opts.minimum<<",\"dps\":"<<opts.dps
            <<",\"schottky_seed_seconds\":"<<seed_seconds<<",\"wall_seconds\":"<<seconds()-started<<"}\n";
        atomic(fs::path(opts.output)/"run.json",report.str());std::cout<<report.str();
        require(ok,"worker failed; inspect worker logs");return 0;
    } catch(const std::exception &e) {std::cerr<<"partition: "<<e.what()<<'\n';return 1;}
}
