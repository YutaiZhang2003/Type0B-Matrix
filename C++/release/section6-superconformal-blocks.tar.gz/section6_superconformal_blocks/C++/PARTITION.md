# Partition functions in the paper's block basis

The production code computes and stores the paper's literal `F`, with its
Koszul sign, and uses `C_a`, `C_f_eta`, and edge order `(1,2,3)=(infinity,1,0)`.
It constructs no reflected or projected block objects. The geometric spin
pairing is a separate numerical matrix acting on these literal block values.
The current sewing identifier is `paper_F_geometric_pairing_2026-09-24`.

The fresh comparison agrees: the two fixed-spin ratios are
**1.000007836181439** and **1.000003799186142**; their sum gives
**1.000005843991480**. No normalization was fitted. Neither draft was edited.

## What was fixed

The geometry module explicitly distinguishes its raw determinant signs from
the literal lift arguments in the Human Notes. Replacing the old block
coordinates by literal `F` while also replacing the sewing matrix by a
diagonal matrix was incorrect. That run gave 0.9590535743 and is retained in
`results/partition_paper_blocks_2026-09-24`.

The correction transforms the **sewing coefficients**, keeping every block
unchanged. This is algebraically the same geometric pairing formerly written
with reflected blocks; it is not a new physical pairing or a fitted adjustment.
The current API exposes only `F` and its explicit pairing. The independently
bosonized Majorana test verifies this convention before Liouville integration.
The earlier coherent combinations of different geometric spins have also
been removed. The comparison now pairs the two marked spins separately.

## Formulas

Indices `i,j` enumerate the four literal arguments
`eta_e=(+++),(+-+),(++-),(+--)`, always in paper edge order. For all NS:

\[
 Z=\int\prod_e\frac{dp_e}{\pi}|q_e^{h_e}|^2
 \sum_{a=0}^1(-1)^a C_a^2\sum_{i,j=1}^4
 M^{(a)}_{ij}\mathbf F^{(a)}(q;\eta^{(i)})
 \overline{\mathbf F^{(a)}(q;\eta^{(j)})}.
\]

`C_1` includes its factor of `i`. The entries of `4 M` are the pairwise
products of the four signs in the appropriate column:

| Charge spin | a=0 | a=1 |
| --- | --- | --- |
| [00\|00] | (-,+,+,+) | (+,+,+,-) |
| [00\|01] | (+,-,+,+) | (+,+,-,+) |
| [00\|10] | (+,+,-,+) | (+,-,+,+) |
| [00\|11] | (+,+,+,-) | (-,+,+,+) |

`NS_pairing()` derives these integers from state parity. Inverting the
four lift characters supplies a factor 1/4 on each side. Because each
literal coefficient already contains `(-1)^K`, the fixed geometric state
pairing acquires `(-1)^(K(epsilon)+K(epsilon_tilde))` in this basis. The code
contracts the resulting matrix directly; it never forms a transformed block.
Independent antiholomorphic inputs are accepted by the bilinear API.

For the NSRR source marked spin [11|00], the physical Ramond-family pairing is

\[
 Z=\frac12\int\prod_e\frac{dp_e}{\pi}|q_e^{h_e}|^2
 \sum_{\eta=\pm1}C_{0,\eta}^2\sum_{i,j=1}^2
 \mathbf F^{(0,\eta,\eta)}(q;\eta^{(i)})
 \overline{\mathbf F^{(0,\eta,\eta)}(q;\eta^{(j)})}.
\]

For [11|11], replace `i,j=1,2` by `i,j=3,4`. This reverses the NS parity
character. The two unit-norm Ramond families have amplitudes
`C_{0,+}+C_{0,-}` and `C_{0,+}-C_{0,-}`; their norm sum eliminates unequal
vertex signs. The constant Clifford contraction extends to every descendant
multiplicity space. `C_{1,eta}=C_{0,eta}` in this reduced coefficient convention.
The identity-residue normalization remains unchanged; see
[PARTITION_NORMALIZATION.md](PARTITION_NORMALIZATION.md).

The two source spins transport to target marked spins [00|00], [00|10],
whose charge-frame spins are [00|10], [00|00]. The configuration records the
symplectic map and integer period shifts. These are geometric spin labels,
not indices identifying a single literal block value.

## Calculation and inputs

The source uses double Virasoro, the Schottky vacuum, and restricted fermion
division. Both f sectors and both `eta=eta'=+1,-1` are computed directly and
saved at all four lifts. The integration needs f=0; the saved f=1 values
remain independently computed. Opposite vertex-sign sectors are absent from
this run's channel list, not reported as zero.

The target uses SCA c-recursion with the full Schottky large-c seed, shared
across all momenta. Both channels reuse the maximum-level coefficient bank
for lower cutoffs. Neither loads saved blocks. Both cutoffs are total
descendant levels, with half levels included.

`prepare_partition_inputs.py` imports only geometry, momenta, measures,
constants and free factors. It reverses the historical geometry edge order
once and converts `(C,Ctilde)` to `(C_0,C_1)=(C,i*Ctilde)`. The native schema
requires `C_a` or `C_f_eta`, paper-order momenta and q, and explicit spin data.
The input conversion does not recompute special functions or uniformization.
For other callers, the generic structure-constant provider exposes `.C_a`
and `.C_f_eta` in paper order; these Python interfaces return binary64 values.

## Reproduce

From the repository root, with fresh output directories:

```sh
make -C C++ partition check-partition
python3 C++/tools/prepare_partition_inputs.py \
  --input 'Data Set/nsrr_bilinear_quadrature_20260915' --output /tmp/paper-inputs
python3 C++/tests/partition_spin_geometry.py \
  --config /tmp/paper-inputs/config.json --output /tmp/spin-geometry-test.json
C++/bin/partition --config /tmp/paper-inputs/config.json \
  --node-directory /tmp/paper-inputs/source --channel source \
  --level 5 --minimum-level 3 --dps 40 --workers 4 --output /tmp/paper-source
C++/bin/partition --config /tmp/paper-inputs/config.json \
  --node-directory /tmp/paper-inputs/target --channel target \
  --level 8 --minimum-level 6 --dps 40 --workers 4 --output /tmp/paper-target
C++/bin/partition --config /tmp/paper-inputs/config.json \
  --reduce-source /tmp/paper-source --reduce-target /tmp/paper-target \
  --dps 40 --output /tmp/paper-comparison.json
```

`tools/section6_partition.py` delegates to the native executable. `--index I`
selects one node; reduction requires complete unique grids, successful worker
metadata, and matching conventions and precision. The former reflected
Python adapter is archived, and its original import path raises an error.
Obsolete Python sewing adapters are excluded from the production archive.

## Results and checks

| Calculation | Grid | Total level | Wall time, four workers |
| --- | ---: | ---: | ---: |
| NSRR, both f computed directly | 7³ | 5 | 69.04 s |
| All NS, four literal lifts | 10³ | 8 | 53.83 s |

Total block/integration time: **122.86 s**, excluding build, input conversion,
and the 0.08 s reduction. Arithmetic used 40 digits; frozen physical inputs
have roughly binary64 accuracy. No new momentum-grid refinement was run.

For the two fixed spins, source level 4 to 5 changes the result by 1.50e-5
and 5.90e-5; target level 7 to 8 changes it by 8.08e-8 and 7.55e-8.
The residual discrepancies 7.84e-6 and 3.80e-6 are smaller than the observed
source cutoff changes. These comparisons do not bound all omitted terms or
establish arbitrary-surface convergence.

Directed checks passed:

* 32 finite Ramond Clifford contractions and 32 NS grading identities per
  precision; independent bilinear inputs and the unit-normalized identity trace.
* Native geometric NS pairing against an independent parity state sum.
* Two marked-spin transports against their symplectic map and period shifts.
* 228 Majorana Wick monomials through level 8, compared with independent
  charge-lattice bosonization for all four NS spins: maximum error 8.61e-9.
  The incorrect diagonal pairing fails the same check by 5.53–31.9%.
* Through total level 3, 480 literal Ramond lift coefficients versus direct
  PBW: maximum scaled error 2.47e-27; 84 all-NS coefficients: 3.48e-38.
* Every saved literal F row is unchanged by the pairing correction:
  1,029 source rows and 3,000 target rows.

Fresh nodes, input provenance, checks, timings and results are saved in
[results/partition_paper_pairing_2026-09-24](results/partition_paper_pairing_2026-09-24).
