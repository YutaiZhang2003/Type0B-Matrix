# Genus-two NS free-superfield and spin-transport review map

This bundle records the code used to form

\[
Q_L^{\rm pl}=\frac{Z_L^{\rm pl}}
{\left(Z_{X+\psi}^{\rm pl}\right)^9}
\]

in the theta and glasses plumbing frames, together with the completed
five-point \(R=24,N=10\) result and independent regression checks.  No
theta/glasses agreement is imposed.

## Free-superfield formula

For the primitive Schottky multipliers \(k_\gamma\) in the selected plumbing
marking,

\[
P_X^{\rm pl}(\mathbf q)
=\prod_{[\gamma]\in\mathcal P_{\rm prim}}
 \prod_{n=1}^{\infty}(1-k_\gamma^n)^{-1}.
\]

With unit connected target-space zero-mode volume, one real scalar and one
Majorana fermion contribute

\[
Z_{X+\psi}^{\rm pl}
=(\det\operatorname{Im}\Omega)^{-1/2}
\left|\vartheta[\delta](0|\Omega)\right|
\left|P_X^{\rm pl}\right|^3.
\]

The factor \((\det\operatorname{Im}\Omega)^{-1/2}\) is the two-handle scalar
momentum Gaussian.  The Majorana factor is evaluated by exact bosonization,
\(Z_{\psi,L}^{\rm pl}=(\vartheta[\delta]P_X^{\rm pl})^{1/2}\).  The common
edge Casimir powers are stripped in both numerator and denominator.

## Spin marking fixed in this snapshot

The complete branch-composed glasses-to-theta matrix is

\[
M=\begin{pmatrix}
0&0&-1&-1\\
0&0&0&-1\\
1&0&0&0\\
-1&1&0&0
\end{pmatrix}.
\]

For \(\Omega'=(A\Omega+B)(C\Omega+D)^{-1}\), characteristics are transported
by

\[
\alpha'=D\alpha-C\beta+\operatorname{diag}(CD^T),\qquad
\beta'=-B\alpha+A\beta+\operatorname{diag}(AB^T)\pmod2.
\]

This maps \([00|00]\) to \([00|00]\).  Both channel configurations therefore
use physical plumbing lifts \((+,+,+)\).  The older pre-branch theta marking
\((+,+,-)\), which realizes \([00|11]\), is not used after the final integer
branch transformation.  A Cannon configuration that declares
`expected_spin_characteristics` now fails before shard evaluation if its
lifts do not realize the declared characteristic.

## Primary review files

- `Code/ns_genus2_partition.py`: Liouville integrand, recursion, global-block
  resummations, free-superfield denominator, spin characteristic and analytic
  checks.
- `Code/ns_genus2_cannon.py`: array design, deterministic reduction,
  configuration spin validation, and formation of \(Q_L\).
- `Code/test_ns_genus2_partition.py`: twenty genus-two regressions.
- `Code/python/free_boson_pair_of_pants.py`: independent direct Heisenberg
  descendant sewing, which does not use the primitive-word product.
- `Code/python/free_boson_plumbing.py`: scalar zero-mode conventions and
  Riemann theta constants.
- `Code/python/plumbing_algorithms.py`: theta/glasses plumbing maps, Schottky
  generators, and period maps.
- `Code/python/genus2_vacuum_blocks.py`: primitive conjugacy words and word
  multipliers.
- `Code/ns_vacuum_schottky.py`: lifted NS Schottky product.
- `Data Set/ns_genus2_fivepoint_r24_n10_affine_summary.json`: complete
  five-point configuration, provenance, spin ledgers, free denominators,
  Liouville numerators, and channel ratios.

The remaining files in the archive are the recursion, structure-constant,
regular-block, and cluster-entry dependencies imported by these primary files.

## Reproduction checks

From the repository root:

```bash
PYTHONPATH=Code:Code/python python3 -m unittest Code.test_ns_genus2_partition
PYTHONPATH=Code:Code/python python3 Code/python/free_boson_plumbing_checks.py
```

The first command passes 20/20 tests in this snapshot.  To extract the exact
completed-run configuration for a new run:

```bash
jq '.config' 'Data Set/ns_genus2_fivepoint_r24_n10_affine_summary.json' \
  > /tmp/ns_genus2_fivepoint_r24_n10_affine_config.json
```

Then inspect the planned designs without launching work:

```bash
PYTHONPATH=Code:Code/python python3 Code/ns_genus2_cannon.py \
  --config /tmp/ns_genus2_fivepoint_r24_n10_affine_config.json plan
```

## Plumbing-coordinate stability

Across the five points, \(\max|q_e|=0.2479\).  Finite-difference Jacobians of
the period maps in real and imaginary \(\log q_e\) coordinates have condition
numbers between 3.08 and 3.68.  Treating the word-length-eight to nine period
movement as an effective coordinate error gives
\(\max|\delta q_e/q_e|=3.13\times10^{-9}\).  The largest resulting relative
change of one free-superfield denominator is below \(2.7\times10^{-9}\), or
\(2.4\times10^{-8}\) after the ninth power.  Increasing the genus-two theta
lattice cutoff to 16 changes the theta constants by at most
\(2.3\times10^{-16}\).

At `o0239`, direct scalar descendant sewing approaches the resummed primitive
product as follows:

| total sewing level | theta relative error | glasses relative error |
|---:|---:|---:|
| 4 | \(1.80\times10^{-9}\) | \(1.41\times10^{-3}\) |
| 6 | \(8.92\times10^{-11}\) | \(2.97\times10^{-4}\) |
| 8 | \(3.96\times10^{-12}\) | \(6.91\times10^{-5}\) |

These errors are truncation errors of the independent direct sum; the
primitive product itself is carried to word length 14 and mode 70 in the
completed calculation.

## Scope note

The completed numerical summary already used the branch-composed
\([00|00]\) configuration.  The code correction in this snapshot repairs the
stale pre-branch analytic assertion and makes future configuration checking
fail closed; it does not retroactively alter the stored five-point numerical
values.
